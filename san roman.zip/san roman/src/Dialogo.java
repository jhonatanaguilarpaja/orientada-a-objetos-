import javax.swing.*;
import java.sql.*;
import java.awt.event.*;

public class Dialogo extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;
    private JTextField texret_d; // Código
    private JTextField text_E; // Nombre
    private JTextField text_F; // Dirección
    private JTextField text_g; // Distrito
    private JTextField text_i; // Gestión
    private JTextField text_h; // Nivel
    private JTextField text_id; // ID

    // Constructor corregido
    public Dialogo(int id, String codigo, String nombre, String direccion, String distrito, String nivel, String gestion, Connection cone) {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);
        setSize(300, 300); // Ajustado el tamaño
        setLocationRelativeTo(null);

        // Establecer valores iniciales de los campos de texto con los datos existentes
        textField1.setText(String.valueOf(id));
        textField2.setText(codigo);
        textField3.setText(nombre);
        textField4.setText(direccion);
        textField5.setText(distrito);
        textField6.setText(nivel);
        textField7.setText(gestion);

        // Acción al hacer click en "OK"
        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // Preparar la consulta SQL para actualizar los datos
                    String sql = "UPDATE institucion SET codigo=?, nombre=?, direccion=?, distrito=?, nivel=?, gestion=? WHERE id=?";
                    PreparedStatement ps = cone.prepareStatement(sql);
                    ps.setString(1, textField2.getText());
                    ps.setString(2, textField2.getText());
                    ps.setString(3, textField3.getText()); // Dirección
                    ps.setString(4, textField4.getText()); // Distrito
                    ps.setString(5, textField5.getText()); // Nivel
                    ps.setString(6, textField6.getText()); // Gestión
                    ps.setInt(7, Integer.parseInt(textField1.getText())); // ID

                    // Ejecutar la actualización en la base de datos
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Datos actualizados correctamente");

                    // Cerrar la ventana de diálogo
                    dispose();

                } catch (SQLException ex) {
                    // Mostrar mensaje en caso de error
                    JOptionPane.showMessageDialog(null, "Error al actualizar: " + ex.getMessage());
                }
            }
        });

        // Acción al hacer click en "Cancelar"
        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // Lógica para cerrar el diálogo con la cruz (botón de cierre)
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // Lógica para cerrar el diálogo con la tecla ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    // Método para cancelar el diálogo
    private void onCancel() {
        dispose();  // Cerrar el diálogo
    }
}
