import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class FormInstitucion  extends JFrame {
    private JPanel institucion;
    private JTable table1;
    private JButton modificarButton;
    private JButton eliminarButton;
    private JButton listarButton;
    private JButton nuevoButton;
    private JButton guardarButton;
    private JTextField text_codigo;
    private JTextField text_nombre;
    private JTextField text_direccion;
    private JTextField text_distrito;
    private JTextField text_nivel;
    private JTextField text_gestion;
    private JLabel codigo;
    private JLabel nombre;
    private JLabel direccion;
    private JLabel distrito;
    private JLabel nivel;
    private JLabel gestion;
    String url = "jdbc:mysql://localhost:3306/ugel_san_roman";
    String usuario_bd = "root";
    String password_bd = "";


    public Connection metodo_conexion() {
        Connection conec = null;
        try {
            conec = DriverManager.getConnection(url, usuario_bd, password_bd);
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos");
        }
        return conec;
    }


    public FormInstitucion() {
        setContentPane(institucion);
        setTitle("Formulario de Institucion");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(700, 600);
        setResizable(true);
        setVisible(true);


        listarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Connection PruebaConexion = metodo_conexion();
                if (PruebaConexion != null) {


                    System.out.println("exelente , la BD ha respondidio.");



                    try {

                        Statement statement = PruebaConexion.createStatement();
                        ResultSet resultset = statement.executeQuery("SELECT * FROM institucion");

                        DefaultTableModel modelo = new DefaultTableModel();
                        modelo.setColumnIdentifiers(new Object[]{"Id", "Codigo", "nombre", "direccion", "distrito", "nivel", "gestion"});
                        modelo.setRowCount(0);

                        while (resultset.next()) {
                            Object[] fila = new Object[7];
                            fila[0] = resultset.getString("id");
                            fila[1] = resultset.getString("codigo");
                            fila[2] = resultset.getString("nombre");
                            fila[3] = resultset.getString("direccion");
                            fila[4] = resultset.getString("distrito");
                            fila[5] = resultset.getString("nivel");
                            fila[6] = resultset.getString("gestion");
                            modelo.addRow(fila);
                        }
                        table1.setModel(modelo);
                    } catch (SQLException ex) {
                        System.out.println("Error al acceder a la tabla institucion");
                    }
                } else {
                    System.out.println("No se encontró conexión");
                }
            }
        });
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Connection LaConexion = metodo_conexion();
                if (LaConexion != null) {
                    int confirmacion = JOptionPane.showOptionDialog(null,
                            "Estas Seguro de Eliminar esta institucion?",
                            "Cuidado",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            new Object[]{"Si, Eliminar", "no"},
                            "No");
                    if (confirmacion != JOptionPane.YES_OPTION) {
                        return;
                    }
                    int filaSeleccionada = table1.getSelectedRow();
                    int id_producto = Integer.parseInt(table1.getModel().getValueAt(filaSeleccionada, 0).toString());
                    try {
                        // Modificado a la tabla 'institucion'
                        String sql = "DELETE FROM institucion WHERE id=?";
                        PreparedStatement statement = LaConexion.prepareStatement(sql);
                        statement.setInt(1, id_producto);
                        statement.execute();
                        JOptionPane.showMessageDialog(null, "Institución eliminada exitosamente");
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                    }
                }


            }
        });
        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = table1.getSelectedRow();
                if (filaSeleccionada == -1) {
                    JOptionPane.showMessageDialog(null, "Seleccione una institucion");
                    return;
                }

                int id = Integer.parseInt(table1.getValueAt(filaSeleccionada, 0).toString());
                String codigo = table1.getValueAt(filaSeleccionada, 1).toString();
                String nombre = table1.getValueAt(filaSeleccionada, 2).toString();
                String direccion = table1.getValueAt(filaSeleccionada, 3).toString();
                String distrito = table1.getValueAt(filaSeleccionada, 4).toString();
                String nivel = table1.getValueAt(filaSeleccionada, 5).toString();
                String gestion = table1.getValueAt(filaSeleccionada, 6).toString();

                Connection Conexion_Modi = metodo_conexion();
                Dialogo ventanita = new Dialogo(id, codigo, nombre, direccion, distrito, nivel, gestion, Conexion_Modi);
                ventanita.setVisible(true);




            }
        });
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Connection Laconexion = metodo_conexion();
                if (Laconexion != null) {
                    String codigo = text_codigo.getText();
                    String nombre = text_nombre.getText();
                    String direccion = text_direccion.getText();
                    String distrito = text_distrito.getText();
                    String nivel = text_nivel.getText();
                    String gestion = text_gestion.getText();


                    try {
                        // Modificado a la tabla 'institucion'
                        String sql = "INSERT INTO institucion (codigo, nombre, direccion, distrito, nivel, gestion) VALUES(?,?,?,?,?,?)";
                        PreparedStatement statement = Laconexion.prepareStatement(sql);
                        statement.setString(1, codigo);
                        statement.setString(2, nombre);
                        statement.setString(3, direccion);
                        statement.setString(4, distrito);
                        statement.setString(5, nivel);
                        statement.setString(6, gestion);
                        statement.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Datos agregados exitosamente");
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                        System.out.println("Error al agregar institucion");
                    }
                } else {
                    System.out.println("No se pudo conectar con la base de datos");
                }




            }
        });
        nuevoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Limpiar campos de texto y habilitar para ingresar nuevos datos
                codigo.setText("");
                nombre.setText("");
                direccion.setText("");
                distrito.setText("");
                nivel.setText("");
                gestion.setText("");

                // Habilitar los campos de texto para ingresar datos
                text_codigo.setEditable(true);
                text_nombre.setEditable(true);
                text_direccion.setEditable(true);
                text_distrito.setEditable(true);
                text_nivel.setEditable(true);
                text_gestion.setEditable(true);




            }
        });
    }
    public static void main(String[] args) {
        new FormInstitucion();

    }
}
